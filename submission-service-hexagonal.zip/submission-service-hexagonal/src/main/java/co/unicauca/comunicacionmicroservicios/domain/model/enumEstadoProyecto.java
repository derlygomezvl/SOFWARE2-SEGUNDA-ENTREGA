package co.unicauca.comunicacionmicroservicios.domain.model;

public enum enumEstadoProyecto {
    EN_PROCESO, APROBADO, RECHAZADO, RECHAZADO_DEFINITIVO, RECHAZADO_POR_COMITE, ESCRIBIENDO_ANTEPROYECTO;
}

