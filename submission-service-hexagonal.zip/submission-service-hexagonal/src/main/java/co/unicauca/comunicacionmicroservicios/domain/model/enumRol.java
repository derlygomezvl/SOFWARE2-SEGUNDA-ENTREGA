package co.unicauca.comunicacionmicroservicios.domain.model;

public enum enumRol {
    ESTUDIANTE, DOCENTE, ADMIN
}
