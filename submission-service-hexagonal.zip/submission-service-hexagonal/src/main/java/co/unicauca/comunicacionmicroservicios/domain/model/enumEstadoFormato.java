package co.unicauca.comunicacionmicroservicios.domain.model;

public enum enumEstadoFormato {
    PENDIENTE, APROBADO, RECHAZADO
}
